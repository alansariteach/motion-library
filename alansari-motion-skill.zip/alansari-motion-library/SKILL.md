---
name: alansari-motion-library
description: Applies named motion graphics presets (M-001 to M-1000) and fonts (FA-xx Arabic, FE-xx English) from the Alansari.Tech Motion Library when editing Reels, TikTok or Shorts videos. Use whenever the user names a motion by ID or name (for example M-016, Circle Reveal, Fade Up), says مكتبة الموشن, طبّق حركة, or asks for a font by ID (FA-02, FE-10) or name. Also use when the user says a line and tells you which motion to apply on it.
---

# Alansari.Tech Motion Library

The user edits vertical videos (1080x1920, 30fps) and names motions and fonts by ID.
You apply exactly what the library specifies. The library is the source of truth.

## Step 1: get the latest library
Fetch the live file and read only the entries the user mentioned:
- Arabic: https://alansariteach.github.io/motion-library/alansari-motion-library-ar.md
- English: https://alansariteach.github.io/motion-library/alansari-motion-library.md

If the fetch fails (no internet or blocked), read the bundled copy at `references/alansari-motion-library-ar.md` and tell the user it may be slightly out of date.

## Step 2: apply it
- Find the entry by ID (M-016) or by name. Follow its Spec, Duration and Easing exactly.
- Read its "Content the user must provide" line. If the user did not give that content (text, image, logo, handle, screen recording), ask for it before rendering. Never invent logos, screenshots or numbers.
- Variants (Fast, Slow, Gold, Boxed) need the same content as their base motion.
- Start the motion on the exact frame of the word or action the user names.
- Keep text inside the Reels safe zone: y 300 to 1550, x 60 to 1020.
- Motions can be chained: "M-016 then M-038".
- For fonts, use the entry in the Fonts table (ID, name, Google Fonts link). Use an Arabic font (FA-xx) for Arabic text. Download it from the link or from the file URL in the JSON, register it before rendering.

## Step 3: check
Export stills of each motion moment and check timing, overlaps and the safe zone before the final render.

## Notes
- Motion names are English and fixed. Use them as written.
- Reply in the language the user writes in (the users usually write Gulf Arabic).
- Examples of each motion: https://alansariteach.github.io/motion-library/ (button: معاينة المثال).
